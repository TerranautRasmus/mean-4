# MEAN-Period4Exercises
School exercises for the MEAN course - CPHBusiness Computer Science

This repository includes a seed for a MEAN application
and questions from period 4 in the MEAN course.

Look at code and Questions.txt


to run project:

open in webstorm or similar.

in terminal: npm install

(if bower not installed on your machine)

(you can leave out -g if you want)

in terminal: npm install -g bower

in terminal: bower install

this will download the required packages to get the project to run.

Webpage will be on:
localhost:3000
---------------

To run program

1. F:\MEAN MASTER\CODE EXAMPLES\Period4\mean-4-master\meanSeed
2. Open a terminal and write [npm install]
3. [npm install --save bcryptjs]
4. Start database (MongoDB)
5. run bin/www.js
6. Start a browser with http://localhost:3000/

